import React, { useEffect, useState } from 'react';
import { Pie } from 'react-chartjs-2';
import axios from 'axios';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';

ChartJS.register(ArcElement, Tooltip, Legend);

const PieChart = ({ month }) => {
    const [data, setData] = useState([]);

    useEffect(() => {
        fetchPieChartData();
    }, [month]);

    const fetchPieChartData = async () => {
        const response = await axios.get('http://localhost:5000/api/pie-chart', { params: { month } });
        setData(response.data);
    };

    const chartData = {
        labels: data.map(d => d._id),
        datasets: [{
            data: data.map(d => d.count),
            backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56'],
        }]
    };

    return <Pie data={chartData} />;
};

export default PieChart;
