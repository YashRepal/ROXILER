import React, { useEffect, useState } from 'react';
import axios from 'axios';

const TransactionsTable = ({ month, setMonth, setStatistics }) => {
    const [transactions, setTransactions] = useState([]);
    const [search, setSearch] = useState('');
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(0);

    useEffect(() => {
        fetchTransactions();
    }, [month, search, page]);

    const fetchTransactions = async () => {
        const response = await axios.get('http://localhost:5000/api/transactions', {
            params: { month, search, page, perPage: 10 }
        });
        setTransactions(response.data.transactions);
        setTotalPages(response.data.totalPages);
        fetchStatistics();
    };

    const fetchStatistics = async () => {
        const response = await axios.get('http://localhost:5000/api/statistics', {
            params: { month }
        });
        setStatistics(response.data);
    };

    return (
        <div>
            <select value={month} onChange={(e) => setMonth(e.target.value)}>
                {['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'].map((m, index) => (
                    <option key={m} value={index + 1}>{m}</option>
                ))}
            </select>
            <input 
                type="text" 
                value={search} 
                onChange={(e) => setSearch(e.target.value)} 
                placeholder="Search transactions" 
            />
            <table>
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Price</th>
                    </tr>
                </thead>
                <tbody>
                    {transactions.map(transaction => (
                        <tr key={transaction._id}>
                            <td>{transaction.title}</td>
                            <td>{transaction.description}</td>
                            <td>{transaction.price}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
            <button disabled={page === 1} onClick={() => setPage(page - 1)}>Previous</button>
            <button disabled={page === totalPages} onClick={() => setPage(page + 1)}>Next</button>
        </div>
    );
};

export default TransactionsTable;
