import React, { useEffect, useState } from 'react';
import { Bar } from 'react-chartjs-2';
import axios from 'axios';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement } from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, BarElement);

const BarChart = ({ month }) => {
    const [data, setData] = useState([]);

    useEffect(() => {
        fetchBarChartData();
    }, [month]);

    const fetchBarChartData = async () => {
        const response = await axios.get('http://localhost:5000/api/bar-chart', { params: { month } });
        setData(response.data);
    };

    const chartData = {
        labels: data.map(d => d.range),
        datasets: [{
            label: 'Number of Items',
            data: data.map(d => d.count),
            backgroundColor: 'rgba(75, 192, 192, 0.6)',
        }]
    };

    return <Bar data={chartData} />;
};

export default BarChart;
