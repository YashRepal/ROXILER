import React, { useState } from 'react';
import TransactionsTable from './components/TransactionsTable';
import Statistics from './components/Statistics';
import BarChart from './components/BarChart';
import PieChart from './components/PieChart';

const App = () => {
    const [month, setMonth] = useState('3'); // Default to March
    const [statistics, setStatistics] = useState({});

    return (
        <div>
            <h1>Transaction Dashboard</h1>
            <TransactionsTable month={month} setMonth={setMonth} setStatistics={setStatistics} />
            <Statistics statistics={statistics} />
            <BarChart month={month} />
            <PieChart month={month} />
        </div>
    );
};

export default App;
