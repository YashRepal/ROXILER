const express = require('express');
const axios = require('axios');
const Transaction = require('../models/Transaction');

const router = express.Router();

// Initialize the database
router.post('/initialize', async (req, res) => {
    try {
        const response = await axios.get('https://s3.amazonaws.com/roxiler.com/product_transaction.json');
        const transactions = response.data.map(item => ({
            title: item.title,
            description: item.description,
            price: item.price,
            dateOfSale: new Date(item.dateOfSale),
            category: item.category,
            sold: item.sold
        }));

        await Transaction.insertMany(transactions);
        res.status(200).send('Database initialized successfully.');
    } catch (error) {
        res.status(500).send('Error initializing database: ' + error.message);
    }
});

// Get transactions with search and pagination
router.get('/', async (req, res) => {
    const { month, search = '', page = 1, perPage = 10 } = req.query;
    const startDate = new Date(`2020-${month}-01`);
    const endDate = new Date(`2020-${month + 1}-01`);

    const query = {
        dateOfSale: { $gte: startDate, $lt: endDate },
        $or: [
            { title: { $regex: search, $options: 'i' } },
            { description: { $regex: search, $options: 'i' } },
            { price: { $regex: search } }
        ]
    };

    const total = await Transaction.countDocuments(query);
    const transactions = await Transaction.find(query)
        .skip((page - 1) * perPage)
        .limit(Number(perPage));

    res.json({ transactions, totalPages: Math.ceil(total / perPage) });
});

// Get statistics
router.get('/statistics', async (req, res) => {
    const { month } = req.query;
    const startDate = new Date(`2020-${month}-01`);
    const endDate = new Date(`2020-${month + 1}-01`);

    const soldItems = await Transaction.find({ dateOfSale: { $gte: startDate, $lt: endDate }, sold: true });
    const notSoldItems = await Transaction.find({ dateOfSale: { $gte: startDate, $lt: endDate }, sold: false });

    const totalSales = soldItems.reduce((acc, item) => acc + item.price, 0);
    res.json({
        totalSales,
        totalSold: soldItems.length,
        totalNotSold: notSoldItems.length
    });
});

// Bar chart data
router.get('/bar-chart', async (req, res) => {
    const { month } = req.query;
    const startDate = new Date(`2020-${month}-01`);
    const endDate = new Date(`2020-${month + 1}-01`);

    const priceRanges = [
        { range: '0-100', count: 0 },
        { range: '101-200', count: 0 },
        { range: '201-300', count: 0 },
        { range: '301-400', count: 0 },
        { range: '401-500', count: 0 },
        { range: '501-600', count: 0 },
        { range: '601-700', count: 0 },
        { range: '701-800', count: 0 },
        { range: '801-900', count: 0 },
        { range: '901-above', count: 0 }
    ];

    const transactions = await Transaction.find({ dateOfSale: { $gte: startDate, $lt: endDate } });

    transactions.forEach(item => {
        const price = item.price;
        if (price <= 100) priceRanges[0].count++;
        else if (price <= 200) priceRanges[1].count++;
        else if (price <= 300) priceRanges[2].count++;
        else if (price <= 400) priceRanges[3].count++;
        else if (price <= 500) priceRanges[4].count++;
        else if (price <= 600) priceRanges[5].count++;
        else if (price <= 700) priceRanges[6].count++;
        else if (price <= 800) priceRanges[7].count++;
        else if (price <= 900) priceRanges[8].count++;
        else priceRanges[9].count++;
    });

    res.json(priceRanges);
});

// Pie chart data
router.get('/pie-chart', async (req, res) => {
    const { month } = req.query;
    const startDate = new Date(`2020-${month}-01`);
    const endDate = new Date(`2020-${month + 1}-01`);

    const categories = await Transaction.aggregate([
        { $match: { dateOfSale: { $gte: startDate, $lt: endDate } } },
        { $group: { _id: '$category', count: { $sum: 1 } } }
    ]);

    res.json(categories);
});

// Combined data API
router.get('/combined', async (req, res) => {
    const { month } = req.query;
    const startDate = new Date(`2020-${month}-01`);
    const endDate = new Date(`2020-${month + 1}-01`);

    const transactions = await Transaction.find({ dateOfSale: { $gte: startDate, $lt: endDate } });
    const soldItems = await Transaction.find({ dateOfSale: { $gte: startDate, $lt: endDate }, sold: true });
    const notSoldItems = await Transaction.find({ dateOfSale: { $gte: startDate, $lt: endDate }, sold: false });

    const totalSales = soldItems.reduce((acc, item) => acc + item.price, 0);

    res.json({
        transactions,
        statistics: {
            totalSales,
            totalSold: soldItems.length,
            totalNotSold: notSoldItems.length
        }
    });
});

module.exports = router;
http://localhost:5000/api/transactions

